/* Main.java
 * This is the main section
 * Author: Vuyisa Lutho Mqoboli (219191018)
 * 26 July 2022
*/
package com.mycompany.userregistration;


public class Main {
    public static void main(String[] args) {
        new UserGUI().setGUI();
    }
}
